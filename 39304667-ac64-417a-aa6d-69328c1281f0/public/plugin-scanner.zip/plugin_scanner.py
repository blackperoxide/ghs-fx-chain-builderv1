#!/usr/bin/env python3
"""
Grand Healing Studio — Local Plugin Scanner
--------------------------------------------
Walks your machine's standard VST3 / AU / AAX plugin folders and writes a plain
text list of installed plugin names to plugins_list.txt in this same folder.

This script only READS your plugin folders and writes one local text file.
It does not send anything anywhere. Nothing leaves your machine unless you
choose to copy/paste or upload plugins_list.txt into the FX Chain Builder app.

Usage:
    python3 plugin_scanner.py

Then open plugins_list.txt, copy its contents, and paste into the
"My Plugin Library" box in the FX Chain Builder app.
"""

import os
import platform
import sys

def mac_paths():
    home = os.path.expanduser("~")
    return [
        "/Library/Audio/Plug-Ins/Components",
        "/Library/Audio/Plug-Ins/VST3",
        "/Library/Audio/Plug-Ins/VST",
        f"{home}/Library/Audio/Plug-Ins/Components",
        f"{home}/Library/Audio/Plug-Ins/VST3",
        f"{home}/Library/Audio/Plug-Ins/VST",
        "/Library/Application Support/Avid/Audio/Plug-Ins",
        "/Library/Application Support/Digidesign/Plug-Ins",
    ]

def windows_paths():
    program_files = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    common = os.environ.get("COMMONPROGRAMFILES", r"C:\Program Files\Common Files")
    return [
        os.path.join(common, "VST3"),
        os.path.join(program_files, "VSTPlugins"),
        os.path.join(program_files, "Steinberg", "VstPlugins"),
        os.path.join(program_files_x86, "VSTPlugins"),
        os.path.join(common, "Avid", "Audio", "Plug-Ins"),
        os.path.join(program_files, "Common Files", "Avid", "Audio", "Plug-Ins"),
    ]

PLUGIN_EXTENSIONS = {".vst3", ".component", ".vst", ".aaxplugin", ".dll"}

def scan_folder(path):
    found = []
    if not os.path.isdir(path):
        return found
    for entry in os.listdir(path):
        name, ext = os.path.splitext(entry)
        if ext.lower() in PLUGIN_EXTENSIONS or os.path.isdir(os.path.join(path, entry)):
            # Directories (like .vst3 bundles or .component bundles) count as plugin names too
            clean_name = name.strip()
            if clean_name and not clean_name.startswith("."):
                found.append(clean_name)
    return found

def main():
    system = platform.system()
    if system == "Darwin":
        paths = mac_paths()
    elif system == "Windows":
        paths = windows_paths()
    else:
        print("Unsupported OS for auto-scan. Please list your plugins manually in the app instead.")
        sys.exit(1)

    all_plugins = set()
    for p in paths:
        for name in scan_folder(p):
            all_plugins.add(name)

    output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins_list.txt")
    with open(output_path, "w") as f:
        for name in sorted(all_plugins, key=str.lower):
            f.write(name + "\n")

    print(f"Found {len(all_plugins)} plugins.")
    print(f"Written to: {output_path}")
    print("Open that file, copy the contents, and paste into the 'My Plugin Library' box in the FX Chain Builder app.")

if __name__ == "__main__":
    main()
