GRAND HEALING STUDIO — LOCAL PLUGIN SCANNER
============================================

WHAT THIS DOES
--------------
Scans the standard plugin install folders on your Mac or Windows machine
(VST3 / AU / AAX) and writes a plain list of what's actually installed to
"plugins_list.txt" in this folder.

It is READ-ONLY. It does not modify, move, or delete anything. It does not
send anything over the network. Nothing leaves your machine unless YOU
copy/paste or upload plugins_list.txt somewhere.

HOW TO RUN IT
-------------
You need Python 3 installed (Mac usually has it built in; on Windows,
install from python.org if "python3" isn't recognized).

1. Unzip this folder anywhere (Desktop is fine).
2. Open Terminal (Mac) or Command Prompt / PowerShell (Windows).
3. Navigate to the folder, e.g.:
     cd Desktop/plugin-scanner
4. Run:
     python3 plugin_scanner.py        (Mac)
     python plugin_scanner.py         (Windows)
5. It will print how many plugins it found and where plugins_list.txt was saved.

WHAT TO DO WITH THE OUTPUT
---------------------------
1. Open plugins_list.txt in any text editor.
2. Select all, copy.
3. Go to the FX Chain Builder app, paste into the "My Plugin Library" box,
   and click "Save Library".
4. Every chain in the app will now highlight which of the suggested plugins
   you actually own, from your real installed list — not guesswork.

NOTE ON COVERAGE
-----------------
This scans standard install locations. If you've installed plugins to a
custom folder, or use a plugin manager that stores things elsewhere, some
may be missed — you can always add missed plugins manually in the text box
in the app (one per line).
